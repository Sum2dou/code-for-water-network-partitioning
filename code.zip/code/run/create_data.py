# coding=utf-8
# @author:      cyw
# @name:        create_data.py
# @software:    PyCharm
# @description:

import numpy as np
import pandas as pd
import wntr
from multiprocessing import Pool


class CreateData:
    """
        生成数据集
        1. normal_pressure 获取生成正常压力数据
        2. pipe_burst 获取爆管压力
        3. sensitive 获取高日高时（或者任意时刻）的灵敏度矩阵
    """
    def __init__(
            self,
            wn,
            burst_level,
            duration=None,
            burst_interval=1800,
            discharge_coeff=0.75):
        """
        Args:
            wn: epanet水力模型
            burst_level: list, 爆管程度
            duration: int，单位：秒（s），模型的爆管模拟总时长，默认值和水力模型一致；如果指定时间则按照指定时间模拟
            burst_interval: 爆管的时间间隔，单位：秒
            discharge_coeff: 爆管公式的系数
        """
        self.wn = wn
        if duration:
            self.duration = duration
        else:
            self.duration = self.wn.options.time.duration
        self.burst_level = burst_level
        self.burst_interval = burst_interval
        self.discharge_coeff = discharge_coeff

    def normal_data(
            self,
            is_save=True,
            Pfname='./datas/normal_pressure_net3_1800h.csv',
            Qfname='./datas/normal_flow_net3.csv'):
        """
        Args:
            is_save: 是否保存数据
            Pfname: 保存正常压力的文件
            Qfname: 保存正常流量的文件
        Return:
            pdata: 正常压力数据，dataframe，(行：时刻；列：节点名称)
            qdata: 正常流量数据，dataframe，(行：时刻；列：水库名称)
        """
        sim = wntr.sim.WNTRSimulator(self.wn)
        result = sim.run_sim()
        wn.reset_initial_values()
        #pdata = result.node['pressure'].iloc[:-1, :-3]
        #qdata = -result.node['demand'].iloc[:-1, -3:]
        pdata = result.node['pressure']
        # qdata = -result.node['demand']
        pdata.to_csv(Pfname)
        # qdata.to_csv(Qfname)
        return pdata

    def _get_diameter(self, node):
        """
        Args:
            node: 节点的名字，str
        Returns:
            diameter：节点node相连的最大的管径，float
        """
        diameter = []
        links = self.wn.get_links_for_node(node)
        for pipe in wn.pipe_name_list:
               diameter.append(self.wn.get_link(pipe).diameter/10)
        return max(diameter)

    def _burst(self, node, area,start):
        """
        Args:
            node: str, 节点id
            area: float，爆管面积
            start_time: 时间，单位：秒，爆管开始的时间
        Returns:
            p_data: 节点node爆管之后的压力数据
            q_data: 节点node爆管之后的漏损流量
            Q: 爆管之后的管网流量
        """
        id = node
        # self.wn.options.time.duration = self.burst_interval * 2
        #self.wn.options.time.duration = start_time + self.burst_interval
        # self.wn.options.time.pattern_start = start_time - self.burst_interval
        node = self.wn.get_node(node)
        node.remove_leak(self.wn)
        node.add_leak(self.wn,
                      area=area,
                      discharge_coeff=self.discharge_coeff,
                      start_time=0,
                      end_time=self.wn.options.time.duration
                      )
        sim = wntr.sim.WNTRSimulator(self.wn)
        result = sim.run_sim()
        self.wn.reset_initial_values()
        p_data = result.node['pressure']
        #q_data = result.node['leak_demand'][id]
        #Q = -result.node['demand']
        return p_data

    def pipe_burst(self, start_time=0, nodes=None):
        """
        Args:
            start_time: 时间，单位：秒，爆管开始的时间
            nodes: list，模拟爆管的节点id集合，如果不指定则默认所有节点均发生爆管
        """
        # if nodes:
        #     node_list = nodes
        # else:
        node_list = self.wn.junction_name_list
        finalp_datas=pd.DataFrame()
        count =0
        for node in node_list:
            # areas = (np.pi * (self._get_diameter(node)**2) / 4)*burst_level
            areas = (np.pi * (0.01 ** 2) / 4) * burst_level
            start = start_time
            P_datas = pd.DataFrame()
            p_data= self._burst(node, areas, start)
            P_datas = pd.concat([P_datas, p_data])
            # P_datas.to_csv(
            #         './datas/burst/' + 'P_' + node + '_' + '%.2f' %
            #         self.burst_level + '.csv')
            print(node + '_' + '%.2f' % self.burst_level + ' is ok!')
            count=count+1
            finalp_datas = pd.concat([finalp_datas, P_datas])
            finalp_datas.to_csv(
                './datas/burst/' + 'FinalP_datastest' + '%.2f' %
                self.burst_level + '.csv')
        self.wn.reset_initial_values()
        print(count)

if __name__ == '__main__':
    #burst_level = np.arange(0.2, 1.6, 1.6)
    burst_level =0.05
    wn = wntr.network.WaterNetworkModel(r'Net3.inp')
    datamodel = CreateData(wn, burst_level)
    datamodel.normal_data()
    # datamodel.pipe_burst()
