import numpy as np
import pandas as pd
import wntr
import matplotlib.pyplot as plt
wn = wntr.network.WaterNetworkModel(r"Net3.inp")
sim = wntr.sim.EpanetSimulator(wn)
results = sim.run_sim()
print(results)

node_keys = results.node.keys()

demand = results.node['demand']
print(demand)
demand.to_excel('demandtest.xlsx')