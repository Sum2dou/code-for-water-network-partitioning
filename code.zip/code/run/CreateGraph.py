import wntr
import numpy as np
import networkx as nx
class CreateGraph:
    """
        根据管网模型创建图结构
    """

    def __init__(self, wn):
        """
        Args:
            wn: wntr模块的epanet水力模型
        """
        self.wn = wn


    def reverse_pipes(self):
        """
        搜集管网模型反向流动的管段
        Returns:
            pipes: list，反流的管段id集合
        """
        time = self.wn.options.time.duration
        self.wn.options.time.duration = 0
        sim = wntr.sim.EpanetSimulator(self.wn)
        result = sim.run_sim()
        self.wn.options.time.duration = time
        self.wn.reset_initial_values()
        pipes = result.link['flowrate'].iloc[0,
                                             :][result.link['flowrate'].iloc[0, :] < 0].keys()
        return pipes

    def wsn_graph(self, remove_reservoirs=True,remove_tanks=True):
        """
        根据管网模型构建管网有向图
        Args:
            remove_reservoirs: 是否从图结构中删除水库
        Returns:
            g: nx.DiGraph对象，管网模型的图结构，有向图
            adjacency_matrix: np.array，data_type:float32, 管网模型的有向图结构的邻接矩阵
        """
        # pipes = self.reverse_pipes()
        g = self.wn.get_graph()
        # g_copy = self.wn.get_graph()
        # 调整反向流动的管段，使其方向和水流方法一致
        # for edge in g_copy.edges:
        #     for pipe in pipes:
        #         if pipe in edge:
        #             g.remove_edge(edge[0], edge[1])
        #             g.add_edge(edge[1], edge[0])
        # # 从图结构中删除水库节点
        if remove_reservoirs:
            for i in range(-self.wn.num_reservoirs, 0, 1):
                g.remove_node(list(g.nodes)[i])
        if remove_tanks:
            for i in range(-self.wn.num_tanks, 0, 1):
                g.remove_node(list(g.nodes)[i])
        return g, np.asarray(
            nx.adjacency_matrix(g).todense()).astype(
            np.float32)

    def knn_graph(self):
        """
        根据管网的连接情况，构建knn图。
        规则如下：
                1. 下游路径小于等于2个管段的路径上的所有节点作为邻居节点，产生连接；
                1. 上游路径小于等于2个管段的路径上的所有节点作为邻居节点，产生连接；
        Returns:
            g: nx.DiGraph对象，管网模型的图结构，有向图
            adjacency_matrix: np.array，data_type:float32, knn图邻接矩阵
        """
        g, adj = self.wsn_graph()
        for n, node in enumerate(g.nodes):
            for v in g.successors(node):  # 取下游节点
                adj[n, list(g.nodes).index(v)] = 1
                for sv in g.successors(v):  # 下游节点的节点
                    adj[n, list(g.nodes).index(sv)] = 1
            for s in g.predecessors(node):  # 取上游节点
                adj[n, list(g.nodes).index(s)] = 1
                for ss in g.predecessors(s):  # 取上游节点的节点
                    adj[n, list(g.nodes).index(ss)] = 1
        return g, adj.astype(np.float32)

    def monitor_graph(self, moniters):
        """
        通过监测点id集合创建监测点的有向图邻接矩阵
        Args:
            moniters: 监测点的id集合
        Returns:
            graph: np.array，data_type:float32, 监测点的邻接矩阵，有向图
            ps: list，监测点的坐标
        """
        g, _ = self.wsn_graph()
        pos = nx.get_node_attributes(g, 'pos')
        # 获取监测点集合的坐标
        ps = []
        for node in moniters:
            ps.append(pos[node])
        # 获取监测点集合的有向图邻接矩阵
        graph = np.zeros((len(moniters), len(moniters)))
        for i, s in enumerate(moniters):
            for j, t in enumerate(moniters):
                if nx.has_path(g, s, t):  # 判断两个监测点之间是否存在路径
                    path = nx.dijkstra_path(g, s, t)
                    if len(list(set(moniters) & set(path))
                           ) <= 2:  # 判断两个监测点之间是否存在其他监测点
                        graph[i, j] = 1
        return graph.astype(np.float32), ps

    def cal_g(self, flow_sensors, monitors):
        """
        计算 g: 流量监测点和压力监测点之间的连接关系，shape：N*M; N表示流量监测点的数量，M表示压力监测点的数量.
        Args:
            flow_sensors: 流量监测点的id
            monitors: 压力监测点的id
        """
        graph, _ = self.wsn_graph(remove_reservoirs=False)
        g = np.zeros((len(flow_sensors), len(monitors)), dtype=np.float32)
        for n, i in enumerate(flow_sensors):
            for m, j in enumerate(monitors):
                if nx.has_path(graph, i, j):
                    g[n, m] = 1
        return g

    def index2id(self, indexs):
        """
        根据提供的节点index集合，将其转换成id集合
        Args:
            indexs: 节点index集合
        """
        ids = []
        for i in indexs:
            ids.append(self.wn.node_name_list[i])
        return ids
